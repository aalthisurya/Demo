var player;

// function InitGame(){
//   const params = new URLSearchParams(location.search);
//   var uid = params.get('uid');
//   return alert(uid);
// }


var uid;

function InitGame()
{
	const params = new URLSearchParams(location.search);
	uid = params.get('uid');
    //alert(uid);
	
	
	
}

function EndGame(gameid,score)
{
	
//alert(score +" "+uid +" "+gameid );
// 	 http://www.appbrowzer.com/games-postback/mobi2fun/score?uid={uid}&game_id={gameid}&score={score}
   
   var xhttp = new XMLHttpRequest();
   xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200)
    {
     
    }
  };
  xhttp.open("GET", "http://www.appbrowzer.com/games-postback/mobi2fun/score?uid="+uid+"&game_id="+gameid+"&score="+score+"", true);
  xhttp.send();

 alert(score +" "+uid +" "+gameid );
}


function loadDoc()
{
  
}
